# Application de Mise en Relation

Cette application permet aux utilisateurs et professionnels de s'inscrire, se connecter, et interagir sur une plateforme simple.

## Fonctionnalités

- Inscription utilisateur et professionnel
- Connexion
- Tableau de bord selon le rôle
- Liste des professionnels
- Déconnexion

## Lancement

1. Installez les dépendances :
```
pip install -r requirements.txt
```

2. Lancez l'application :
```
python app.py
```
